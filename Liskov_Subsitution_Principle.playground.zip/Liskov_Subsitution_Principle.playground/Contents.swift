import Foundation


//============================================================

/*
 LISKOV SUBSITUTION PRINCIPLE ---
 
 Following class do not work as per liskov subsitution principle because Square class is overuling basic function of length (in class Rectangle)
 */
class Rectangle {
    var width: Double
    var hieght: Double
    
    init(width: Double, hieght: Double) {
        self.width = width
        self.hieght = hieght
    }
    
    func area() -> Double {
        width * hieght
    }
}

class Square: Rectangle {
    
    /*
     hieght --> this property of class Rectagle is getting voilated from its original behaviour
     */
    override var width: Double {
        didSet {
            hieght = width
        }
    }
}

//============================================================
/*
 On implementing LISKOV SUBSITUTION PRINCIPLE to over come design voilation
 */

protocol Shape {
    func area() -> Double
}

class NewRecangle: Shape {
    var width: Double
    var hieght: Double
    
    init(width: Double, hieght: Double) {
        self.width = width
        self.hieght = hieght
    }
    
    func area() -> Double {
        hieght * width
    }
}

class NewSquare: Shape {
    let side: Double
    
    init(side: Double) {
        self.side = side
    }
    
    func area() -> Double {
        side * side
    }
}
