import UIKit

/*
 OPEN - CLOSE PRINCIPLE
 OPEN FOR EXTENSION
 CLOSE FOR MODIFICATION
                In the class
 */

class Rectangle {
    let width: Double
    let hieght: Double
    init(width: Double, hieght: Double) {
        self.width = width
        self.hieght = hieght
    }
    
    func calculateArea() -> Double {
        width * hieght
    }
}

class Circle {
    let radius: Double
    
    init(radius: Double) {
        self.radius = radius
    }
    
    func calculateArea() -> Double {
        Double.pi * radius * radius
    }
}

class AreaCalculator {
    
    /*
     Here "area(shape:)->Double" is creating tight coupling which is not a very good approach. And the mathod is repeated twice.
     */
    
    func area(shape: Rectangle) -> Double {
        shape.calculateArea()
    }
    
    func area(shape: Circle) -> Double {
        shape.calculateArea()
    }
}

let areaCalculator = AreaCalculator()
let rectangle = Rectangle(width: 1.0, hieght: 2.0)
areaCalculator.area(shape: rectangle)

let circle = Circle(radius: 1.0)
areaCalculator.area(shape: circle)



//==========================================================================//
/*
 Now making correction with usage of OPEN AND CLOSE PRINCIPLE
 */



protocol Shape {
    func calculateArea() -> Double
}

class NewRectagle: Shape {
    var width: Double
    var hieght: Double
    
    init(width: Double, hieght: Double) {
        self.width = width
        self.hieght = hieght
    }
    
    func calculateArea() -> Double {
        width * hieght
    }
}

class NewCircle: Shape {
    var radius: Double
    
    init(radius: Double) {
        self.radius = radius
    }
    
    func calculateArea() -> Double {
        Double.pi * radius * radius
    }
}

class NewAreaCalculator {
    
    func area(shape: Shape) -> Double {
        shape.calculateArea()
    }
}

let newAreaCalculator = NewAreaCalculator()
let newCircle = NewCircle(radius: 2.0)
newAreaCalculator.area(shape: newCircle)

let newRectangle = NewRectagle(width: 1.0, hieght: 2.0)
newAreaCalculator.area(shape: newRectangle)
