import Foundation
//============================================================

/*
 DEPENDENCY INVERSION PRINCIPLE ---
 
 Following class do not follow dependency inversion principle
 */

struct Order {
    let name: String
    let amount: Double
}

class Handler {
    
    /*
     orderDatabaseOperations --> Forms a tight coupling with container class. This create a depency on class "Handler". In future if we get the requirement for additional feature then existing class will fail to provide
     */
    private let orderDatabaseOperations: OrderDatabaseOperation
    
    init(orderDatabaseOperations: OrderDatabaseOperation) {
        self.orderDatabaseOperations = orderDatabaseOperations
    }
    
    func saveOrder(order: Order) {
        if order.amount != 0 {
            orderDatabaseOperations.saveOrder(order: order)
        } else {
            debugPrint("Order could not be placed")
        }
    }
}

class OrderDatabaseOperation {
    
    func saveOrder(order: Order) {
        debugPrint("Save Order with name \(order.name) and amount \(order.amount) into database")
    }
}

class OrderWebServiceOperation {
    
    func saveOrder(order: Order) {
        debugPrint("Save Order with name \(order.name) and amount \(order.amount) into remote server")
    }
}


//============================================================

/*
 DEPENDENCY INVERSION PRINCIPLE ---
 
 Correcting class with dependency inversion
 */

protocol OrderOperation {
    func saveOrder(order: Order)
}

class NewHandler {
    private var orderOperation: OrderOperation
    
    init(orderOperation: OrderOperation) {
        self.orderOperation = orderOperation
    }
    
    func saveOrder(order: Order) {
        if order.amount != 0 {
            orderOperation.saveOrder(order: order)
        } else {
            debugPrint("Order could not be saved")
        }
    }
}

class NewOrderDatabaseOperation: OrderOperation {
    func saveOrder(order: Order) {
        debugPrint("Save Order with name \(order.name) and amount \(order.amount) into database")
    }
}


class NewOrderWebServiceOperation: OrderOperation {
    func saveOrder(order: Order) {
        debugPrint("Save Order with name \(order.name) and amount \(order.amount) into remote server")
    }
}
