import Foundation
//====================================================

/*
    ---- INTERFACE SEGREGATION PRINCIPLE ----
 
 */

protocol Human {
    func goToWork()
    func buyAHouse()
    func eat()
    func sleep()
}

class Person: Human {
    func goToWork() {
        debugPrint(#function)
    }
    
    func buyAHouse() {
        debugPrint(#function)
    }
    
    func eat() {
        debugPrint(#function)
    }
    
    func sleep() {
        debugPrint(#function)
    }
}

class Lion: Human {
    func goToWork() { // <-- Not applicable in this class
        debugPrint(#function)
    }
    
    func buyAHouse() { // <--- Not applicable in in this class
        debugPrint(#function)
    }
    
    func eat() {
        debugPrint(#function)
    }
    
    func sleep() {
        debugPrint(#function)
    }
}


//====================================================
/*
    ---- INTERFACE SEGREGATION PRINCIPLE ----
 
 CORRECTION ::: CORRECTION ::: CORRECTION ::: CORRECTION
 
 */

protocol Animal {
    func eat()
    func sleep()
}

protocol NewHuman {
    func goToWork()
    func buyAHouse()
}

typealias NewPersonProtocol = Animal & NewHuman

class NewPerson: NewPersonProtocol {
    func goToWork() {
        debugPrint(#function)
    }
    
    func buyAHouse() {
        debugPrint(#function)
    }
    
    func eat() {
        debugPrint(#function)
    }
    
    func sleep() {
        debugPrint(#function)
    }
}

class NewLion: Animal {
    func eat() {
        debugPrint(#function)
    }
    
    func sleep() {
        debugPrint(#function)
    }
}
