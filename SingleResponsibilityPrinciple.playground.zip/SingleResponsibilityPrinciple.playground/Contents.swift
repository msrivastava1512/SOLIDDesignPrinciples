import Foundation

//========================================================================================//
/*
 The modal class
 */
struct EmployeeModal {
    var name: String
    var designation: String
}

//========================================================================================//
/*
 Random Class: ---> Not following "Single Responsibility Principle"
 */
class Employee {
    
    func getEmployeeData() {
        let data = getDataFromAPI()
        let employees = parseEmployeeData(data: data)
        saveDataToDatabase(list: employees)
    }
    
    private func getDataFromAPI() -> Data {
        return Data()
    }
    
    private func parseEmployeeData(data: Data) -> [EmployeeModal] {
        return []
    }
    
    private func saveDataToDatabase(list: [EmployeeModal]) {
        debugPrint("Employee data saved")
    }
}

//========================================================================================//
/*
 Classes that follows "Single Responsibility Principle"
 */

class HttpClientHandler {
    
    func getDataFromAPI() -> Data {
        return Data()
    }
}

class ParserHandler {
    
    func parseEmployeeData(data: Data) -> [EmployeeModal] {
        return []
    }
}

class DatabaseHandler {
    func saveDataToDatabase(list: [EmployeeModal]) {
        debugPrint("Employee data saved")
    }
}

class NewEmployee {

    var httpHandler: HttpClientHandler
    var parserHandler: ParserHandler
    var databaseHandler: DatabaseHandler
    
    init(httpHandler: HttpClientHandler, parserHandler: ParserHandler, databaseHandler: DatabaseHandler) {
        self.httpHandler = httpHandler
        self.parserHandler = parserHandler
        self.databaseHandler = databaseHandler
    }
    
    func getEmployeeData() {
        let data = httpHandler.getDataFromAPI()
        let employees = parserHandler.parseEmployeeData(data: data)
        databaseHandler.saveDataToDatabase(list: employees)
    }
}

//========================================================================================//
